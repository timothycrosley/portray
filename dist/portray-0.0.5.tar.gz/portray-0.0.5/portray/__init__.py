from portray.api import as_html, in_browser, project_configuration, server

__version__ = "0.0.5"
