import mkdocs.commands
import mkdocs.config

# cfg = config.Config(schema=config.DEFAULT_SCHEMA)
# def build_docs(config):
# cfg.load_dict({"site_name": "preconvert", "theme": "readthedocs", "nav": [{"Home": "index.md"}]}
# ...: )
# cfg.validate()
# build(cfg)
